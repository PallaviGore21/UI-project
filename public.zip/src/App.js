import React from 'react'
import Task from './page/Task'
import 'bootstrap/dist/css/bootstrap.min.css';
// import '../sass/main.scss'




export default function App() {
  return <>
  
  <Task/>
  </>
}
